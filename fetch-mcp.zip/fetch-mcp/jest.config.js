export default {
  preset: "ts-jest",
  testEnvironment: "node",
};
